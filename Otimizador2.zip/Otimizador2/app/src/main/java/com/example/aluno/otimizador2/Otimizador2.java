package com.example.aluno.otimizador2;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.orm.SugarContext;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

public class Otimizador2 extends AppCompatActivity implements TimePickerDialog.OnTimeSetListener {
    private TextView mTextView;
    private Button button_lista;
    private RadioButton cafeM;
    private RadioButton almoco;
    private RadioButton cafeT;
    private RadioButton janta;
    private RadioGroup btnGroup;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otimizador2);

        cafeM = (RadioButton) findViewById(R.id.cafeM);
        almoco = (RadioButton) findViewById(R.id.almoco);
        cafeT = (RadioButton) findViewById(R.id.cafeT);
        janta = (RadioButton) findViewById(R.id.janta);
        btnGroup = findViewById(R.id.radio_group);

        button_lista = (Button) findViewById(R.id.button_lista);
        button_lista.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(MainActivity.this, "Laboratório 1!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(Otimizador2.this, Listagem.class));
            }
        });

        mTextView = findViewById(R.id.textView);

        Button buttonTimePicker = findViewById(R.id.button_timepicker);
        buttonTimePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment timePicker = new TimePickerFragment();
                timePicker.show(getSupportFragmentManager(), "time picker");
            }
        });

        Button buttonCancelAlarm = findViewById(R.id.button_cancel);
        buttonCancelAlarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cancelAlarm();
            }
        });
    }

    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, hourOfDay);
        c.set(Calendar.MINUTE, minute);
        c.set(Calendar.SECOND, 0);

        updateTimeText(c);
        startAlarm(c);

        String refeicao = "";
        Date hora = c.getTime();

        if(cafeM.isChecked()){
//            Toast.makeText(this, "Café da Manhã", Toast.LENGTH_SHORT).show();
            refeicao = "Café da Manhã";
        }
        if(almoco.isChecked()){
//            Toast.makeText(this, "Almoço", Toast.LENGTH_SHORT).show();
            refeicao = "Almoço";
        }
        if(cafeT.isChecked()){
//            Toast.makeText(this, "Café da Tarde", Toast.LENGTH_SHORT).show();
            refeicao = "Café da Tarde";
        }
        if(janta.isChecked()){
//            Toast.makeText(this, "Janta", Toast.LENGTH_SHORT).show();
            refeicao = "Janta";
        }
        Refeicao refeicao1 = new Refeicao(refeicao, hora);
        SugarContext.init(Otimizador2.this);
        refeicao1.save();
        SugarContext.terminate();
    }

    private void updateTimeText(Calendar c) {
        String timeText = "Alarme selecionado para: ";
        timeText += DateFormat.getTimeInstance(DateFormat.SHORT).format(c.getTime());

        mTextView.setText(timeText);
    }

    private void  startAlarm(Calendar c) {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, AlertReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 1, intent, 0);

        if (c.before(Calendar.getInstance())) {
            c.add(Calendar.DATE, 1);
        }

        alarmManager.setExact(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pendingIntent);
    }

    private void cancelAlarm() {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, AlertReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 1, intent, 0);

        alarmManager.cancel(pendingIntent);
        mTextView.setText("Alarme cancelado!");
    }
}
