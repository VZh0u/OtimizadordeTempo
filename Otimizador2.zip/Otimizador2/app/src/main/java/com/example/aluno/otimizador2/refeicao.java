package com.example.aluno.otimizador2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class refeicao extends AppCompatActivity {

    private ImageView cafeM;
    private ImageView almo;
    private ImageView cafeT;
    private ImageView janta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_refeicao);

        cafeM = (ImageView) findViewById(R.id.cafeM);
        cafeM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(MainActivity.this, "Laboratório 1!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(refeicao.this, Otimizador2.class));
            }
        });

        almo = (ImageView) findViewById(R.id.almo);
        almo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(MainActivity.this, "Laboratório 1!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(refeicao.this, Otimizador2.class));
            }
        });

        cafeT = (ImageView) findViewById(R.id.cafeT);
        cafeT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(MainActivity.this, "Laboratório 1!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(refeicao.this, Otimizador2.class));
            }
        });

        janta = (ImageView) findViewById(R.id.janta);
        janta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(MainActivity.this, "Laboratório 1!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(refeicao.this, Otimizador2.class));
            }
        });

    }
}
