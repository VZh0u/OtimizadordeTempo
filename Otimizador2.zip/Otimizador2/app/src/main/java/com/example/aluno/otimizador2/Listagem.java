package com.example.aluno.otimizador2;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TimePicker;

import com.orm.SugarContext;
import com.orm.query.Select;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Toast;

//import com.example.aluno.leaveprojeto.models.Roupa;
import com.orm.SugarContext;
import com.orm.query.Select;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class Listagem extends AppCompatActivity {

//    private List<Roupa> roupas;
    private ListView listview;
    private static final String PREFS_NAME = "NamePreference";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listagem);

        listview = findViewById(R.id.listview);

        List <Refeicao> refeicao2 = null;
        SugarContext.init(Listagem.this);
        refeicao2 = Select.from(Refeicao.class).orderBy("refeicao").list();
        SugarContext.terminate();

        final String[] lista = new String[refeicao2.size()];
        final String[] lista_id = new String[refeicao2.size()];
        for (int i = 0; i < refeicao2.size(); i++){
            String data = DateFormat.getTimeInstance(DateFormat.SHORT).format(refeicao2.get(i).getHora());
            lista[i] = ""+refeicao2.get(i).getId()+" - "+refeicao2.get(i).getRefeicao()+" - "+data;
            lista_id[i] = ""+refeicao2.get(i).getId();
            final List<Refeicao> finalRefeicao = refeicao2;
            listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

//                    Toast.makeText(Listagem.this, "P:"+lista_id[position], Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(Listagem.this, Alterar.class);
                    intent.putExtra("id", lista_id[position]);
                    startActivity(intent);

//                    startActivity(new Intent(Listagem.this, Alterar.class));
                }
            });
        }


        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Listagem.this,android.R.layout.simple_list_item_1, lista);
        listview.setAdapter(adapter);

    }
}
