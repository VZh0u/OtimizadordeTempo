package com.example.aluno.otimizador2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TimePicker;

import com.orm.SugarContext;
import com.orm.query.Select;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class Listagem extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listagem);

        ListView listview = findViewById(R.id.listview);

        List <Refeicao> refeicao2 = null;
        SugarContext.init(Listagem.this);
        refeicao2 = Select.from(Refeicao.class).list();
        SugarContext.terminate();

        String[] lista = new String[refeicao2.size()];
        for (int i = 0; i < refeicao2.size(); i++){
            String data = DateFormat.getTimeInstance(DateFormat.SHORT).format(refeicao2.get(i).getHora());
            lista[i] = refeicao2.get(i).getRefeicao()+" - "+data;
        }

    }
}
