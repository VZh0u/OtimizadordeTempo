package com.example.aluno.otimizador2;

import com.orm.SugarRecord;

import java.util.Date;


public class Refeicao extends SugarRecord{
    private Long id;
    private String refeicao;
    private Date hora;

    public Refeicao(String refeicao, Date hora){
        this.refeicao = refeicao;
        this.hora = hora;
    }

    public Refeicao(){

    }

    public Long getId() {
        return id;
    }

    public String getRefeicao() {
        return refeicao;
    }

    public Date getHora() {
        return hora;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setRefeicao(String refeicao) {
        this.refeicao = refeicao;
    }

    public void setHora(Date hora) {
        this.hora = hora;
    }
}
