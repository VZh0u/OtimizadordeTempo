package com.example.aluno.otimizador2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class Alterar extends AppCompatActivity {

    private TextView t1;
//    private TextView t2;
//    private TextView t3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alterar);

        Intent intent = getIntent();
        String parametro = (String) intent.getSerializableExtra("id");
//        String parametro2 = (String) intent.getSerializableExtra("refeicao");
//        String parametro3 = (String) intent.getSerializableExtra("hora");

//        TextView id = (TextView) findViewById(R.id.textView);
//        TextView refeicao = (TextView) findViewById(R.id.textView);
//        TextView hora = (TextView) findViewById(R.id.textView);
        Button alt = (Button) findViewById(R.id.alterar);
        Button exc = (Button) findViewById(R.id.excluir);

//        id.setText(parametro); //Usa isso para inserir o valor do ID no campo id
//        refeicao.setText(parametro2);
//        hora.setText(parametro3);

        //FAZER O SELECT WHERE ID = parametro;
    }
}
