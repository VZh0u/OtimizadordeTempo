package com.example.aluno.otimizador2;

import android.content.SharedPreferences;

public class UnidadePreferida {

    private SharedPreferences preferences;
    private SharedPreferences.Editor editor;

    public UnidadePreferida(SharedPreferences preferences){
        this.preferences = preferences;
        this.editor = this.preferences.edit();
    }

    // Método genérico serve para salvar qualquer tipo de preferencia String
    // não só sua filial
    public void savePreferenceString(String key, String value){
        this.editor.putString(key,value);
        this.editor.commit();
    }

    public String getPreferenceString(String key){
        return this.preferences.getString(key,"");
    }

}